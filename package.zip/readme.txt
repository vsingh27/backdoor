BackDoor
Manuel Gonzales - 
Vishav Singh -

Files:
PDF - Design, User Guide and Test Document.
py - attacker/client and backdoor/required files - inside source folder

requires scapy 2.0+
